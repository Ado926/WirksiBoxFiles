> 🩵 Versión actual: 0.0.1

<h1 align="center">🩵 ̸̷᮫໊᷐͢᷍ᰍ MAKIMA BOT MD</p>
<p>
        <img src= "https://files.catbox.moe/petcot.jpg">
    </p>

---

## Descripción

Este Bot es un super bot de whatsapp que te ofrese variedad de cosas muy funcionales para ti.

---

- **LINKS IMPORTANTES**
- **Canal oficial:** [Aquí](https://whatsapp.com/channel/0029VbAa5sNCsU9Hlzsn651S)
- **Canal de Decos:** [Aquí](https://whatsapp.com/channel/0029VbAOVajAO7RQt3rS683e) 

</details>

---

## **`🩵 Sky Ultra Plus 🩵`**
<a href="https://dash.skyultraplus.com/"><img src="https://files.catbox.moe/62pqnw.jpg" height="100px"></a>

<details>
 <summary><b>:paperclip: Enlaces Importantes</b></summary>

- **Dash:** [`Aquí`](https://dash.skyultraplus.com)
- **Panel:** [`Aquí`](https://panel.skyultraplus.com)

</details>

---

### **`🩵 TERMUX MAKIMA`**

<details>
 <summary><b>:paperclip: Instalacion por termux</b></summary>

<img src="https://files.catbox.moe/ksv9f3.jpg" alt="MakimaBot" style="width: 100%; height: auto; max-width: 500px;">

> Nota: Copia y pega los comandos en termux uno por uno.
```bash
termux-setup-storage
```

```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```

```bash
git clone https://github.com/mantis-has/Makima && cd Makima
```

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

> Si aparece (Y/I/N/O/D/Z) [default=N] ? usa la letra "y" + "ENTER" para continuar con la instalación del bot.

### **🩵 Como activar en caso de que se detiene en Termux**

> Si después de instalar el bot en Termux se detiene (pantalla en blanco, pérdida de conexión a Internet, reinicio del dispositivo), sigue estos pasos:

Abre Termux y navega al directorio del bot:
   
   ```bash
    cd Makima-Bot-MD
   ```

Inicia el bot nuevamente:
  
   ```bash
    npm start
   ```

</details>

---

### **`🩵 CREADOR`**

Este bot es creado por Felix Manuel, el creador de M500 ULTRA BOT 🏆.

</details>

---

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF0000&lines=Este+es+el+Repositorio+de+MAKIMA+BOT-+MD;Creado+por+Félix+Manuel;💎🩵+MakimaBot🩵💎;💎🩵MakimaBot🩵💎)](https://git.io/typing-svg)
